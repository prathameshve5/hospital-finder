<?php
require("config.php");
$email = $_POST['email'];
$q = mysqli_query($con, "select * from user where email='$email'");
if (mysqli_num_rows($q) == 1) {
    ?>
    <script>
        alert("email already exist");
        location.href = "register.html";
    </script>
<?php } else {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $password = $_POST['password'];

    $q = mysqli_query($con, "insert into user (email,first_name,last_name,password) values('$email','$fname','$lname','$password')");
    if ($q) {
        ?>
        <script>
            alert("user registered susscefully");
            location.href = "login.html";
        </script>
    <?php
}
}
?>