<?php
require("config.php");



if (isset($_REQUEST["term"])) {
    // Prepare a select statement
    $sql = "SELECT * FROM hospital_details WHERE city LIKE ?";

    if ($stmt = mysqli_prepare($con, $sql)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $param_term);

        // Set parameters
        $param_term = $_REQUEST["term"] . '%';

        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);

            // Check number of rows in the result set
            if (mysqli_num_rows($result) > 0) {
                // Fetch result rows as an associative array
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    ?>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="hpanel hblue contact-panel contact-panel-cs responsive-mg-b-30">
                            <div class="panel-body custom-panel-jw" style="background:#b3d5ff; padding:10px;">


                                <h3><?php echo $row['name']; ?></h3>
                                <p class="all-pro-ad"><?php echo $row['city']; ?></p>
                                <p>
                                    <?php echo $row['address']; ?>
                                </p>
                                <p><?php echo "<b>facilities</b>:" . $row['facility']; ?>
                                </p>
                                <p><?php echo "<b>contact</b>:" . $row['contact']; ?>
                                </p>
                            </div>

                        </div>
                    </div>
                <?php
            }
        } else {
            echo "<p>No matches found</p>";
        }
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
    }
}

// Close statement
mysqli_stmt_close($stmt);
}

// close connection
mysqli_close($con);
