<?php session_start();
require("../config.php");
if (!isset($_SESSION['username'])) {
    header("location:login.html");
} else {

    $id =  $_GET['id'];
    $ff = $_GET['ff'];
    if ($ff == "fff") {
        $q = mysqli_query($con, "delete from hospital_details where id='$id' ");
        if ($q) {
            ?>

            <script src="js/vendor/jquery-1.12.4.min.js"></script>
            <script>
                $(document).ready(function() {
                    alert("record deleted");
                    location.href = "home.php";
                });
            </script>
        <?php
    }
} else {

    ?>
        <input type="hidden" value="<?php echo $id; ?>" id="qq">
        <script src="js/vendor/jquery-1.12.4.min.js"></script>
        <script>
            $(document).ready(function() {
                var id = $("#qq").val();
                var r = confirm("really want to delete entry with id = " + id);
                if (r == true) {
                    location.href = "delete.php?id=" + id + "&ff=fff";
                } else {
                    location.href = "home.php";
                }
            });
        </script>
    <?php
}
}
