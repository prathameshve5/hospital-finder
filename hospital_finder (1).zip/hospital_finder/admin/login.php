<?php
session_start();
require("../config.php");
$email = $_POST['email'];
$password = $_POST['password'];

//$q = mysqli_query($con, "select email from admin where email='$email' AND password='$password'");
if ($email == "admin@admin.com" and $password == "admin") {
    $_SESSION['username'] = $email;
    header("location:home.php");
} else {
    ?>
    <script>
        alert("wrong username or password");
        window.location.herf = "login.html";
    </script>
<?php
}
