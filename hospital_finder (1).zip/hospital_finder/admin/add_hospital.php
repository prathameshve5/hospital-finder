<?php session_start();
if (!isset($_SESSION['username'])) {
    header("location:login.html");
}
require("../config.php");
if ($_POST['hospital_name'] != "" and $_POST['city'] != "") {
    $hospital_name = $_POST['hospital_name'];
    $facility = $_POST['facility'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $q = mysqli_query($con, "insert into hospital_details (name,city,address,contact,facility)values('$hospital_name','$city','$address','$contact','$facility')");
    if ($q) {
        header("location:home.php");
    }
} else {
    header("location:home.php");
}
