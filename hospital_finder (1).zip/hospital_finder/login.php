<?php
session_start();
require("config.php");
$email = $_POST['email'];
$password = $_POST['password'];

$q = mysqli_query($con, "select email from user where email='$email' AND password='$password'");
if (mysqli_num_rows($q) == 1) {
    $_SESSION['email'] = $email;
    header("location:home.php");
} else {
    ?>
    <script>
        alert("wrong username or password");
        location.href = "login.html";
    </script>
<?php
}
